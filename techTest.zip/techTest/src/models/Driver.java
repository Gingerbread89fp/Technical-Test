package models;

public class Driver{
	
	private String car_type;
	private String supplier;
	private int nr_pax;
	private int price;
	
	
	public Driver (String car_type, String supplier, int nr_pax, int price){
		this.car_type = car_type;
		this.supplier = supplier;
		this.nr_pax = nr_pax;
		this.price = price;
	}


	public String getCar_type() {return car_type;}
	public void setCar_type(String car_type) {this.car_type = car_type;}


	public String getSupplier() {return supplier;}
	public void setSupplier(String supplier) {this.supplier = supplier;}


	public int getNr_pax() {return nr_pax;}
	public void setNr_pax(int nr_pax) {this.nr_pax = nr_pax;}


	public int getPrice() {return price;}
	public void setPrice(int price) {this.price = price;}


	@Override
	public String toString() {
		return "Car type= " + this.car_type + " - Supplier= " + this.supplier + " - Price= " + this.price 
				+ "\n Passengers= " + this.nr_pax +" \n ------------ \n";
	}
	
	
	
}
