package techTest;

import java.io.*;
import java.net.*;
import java.util.*;
import org.json.*;

import models.Driver;


public class HandlerApi {
	
	String[]names = {"dave", "jeff", "eric"};
	String car_type; 
	int nr_pax, price;
	URL url;
	HttpURLConnection urlConnection;
	InputStream inSt = null;
	ArrayList<Driver> allTaxis = new ArrayList<>();
    HashMap<String, String> parameters = new HashMap<>();
	
    
    public ArrayList<Driver> connection(String pickup, String dropoff) throws Exception {
    	
    	for(int i=0; i<names.length; i++) {
	    	//use a try-catch to detect possible errors
			try {
				//specify the URL to be used
				url = new URL("https://techtest.rideways.com/"+names[i]+"?pickup="+pickup+"&dropoff="+dropoff);
				
				//get the connection using the specified URL
				urlConnection = (HttpURLConnection) url.openConnection();
				urlConnection.setReadTimeout(2000);
				urlConnection.setConnectTimeout(2000);
		        
				//notify the server the request type will be a "GET" as we need to retrieve the information
				urlConnection.setRequestMethod("GET");
				urlConnection.setDoInput(true);
				urlConnection.setDoOutput(true);
				//retrieve the data as input stream
				inSt = new BufferedInputStream(urlConnection.getInputStream());
				
				//get my server response code (200 will be OK, 404 not found, 500 server problem)
		        int responseCode = urlConnection.getResponseCode();
		        
		       //if my response code is 200
		       if(responseCode == HttpURLConnection.HTTP_OK){
		    	   //convert the input stream into a string
				    String  resp = convertToString(inSt);
				    
				    //create a JSON object from my input stream string
				    JSONObject jObj = new JSONObject(resp);
				   
				    //create a string to contain just the driver information
					String drivers = (String)jObj.get("supplier_id").toString();
					
					//create a string to contain just the information I need i.e. car type and price
					String options = (String)jObj.get("options").toString();
					
					//create a JSONArray
					JSONArray taxi = new JSONArray(options);

				    //loop through the array to retrieve each taxi information
					for (int j = 0; j < taxi.length(); j++) {
						
						JSONObject result = taxi.getJSONObject(j);
						
				    	car_type = (String)result.get("car_type").toString();
				    	price = Integer.valueOf(result.get("price").toString());
				    	nr_pax = 4;
				    	
				    	if(car_type.equals("PEOPLE_CARRIER") || car_type.equals("LUXURY_PEOPLE_CARRIER")) {
				    		nr_pax = 6;
				    	}
				    	else if(car_type.equals("MINIBUS")) {
				    		nr_pax = 16;
				    	}
				 
				        //create a new Driver object to store the info retrieved
				        Driver driver = new Driver(car_type, drivers, nr_pax, price);
				        
				        //add each object to my arrayList
				        allTaxis.add(driver);
				    }
		        }
		        
		        else{
		        	inSt.skip(8000);
		        	System.out.println("No taxi available for "+names[i]);            
		        }
				
			} 
			catch (IOException e) {
				e.printStackTrace();
			}		
			
			
    	}
    	
    	return allTaxis;
    }
    
    public static String convertToString(InputStream inSt) {
    	Scanner scanner = new Scanner(inSt).useDelimiter("\\A");
        return scanner.hasNext() ? scanner.next() : "";
	}
	
}
