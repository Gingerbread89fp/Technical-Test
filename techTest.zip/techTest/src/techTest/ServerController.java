package techTest;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.webapp.Configuration.ClassList;
import org.eclipse.jetty.webapp.WebAppContext;

public class ServerController {

	public static void main(String[] args) throws Exception {
		
		//create a new object for the Server class and attributes to it the port 8005 
		Server server = new Server(8005);
		WebAppContext context = new WebAppContext();
		context.setResourceBase("webapp");
		context.setContextPath("/techtest");
		
		//configuration
		context.setAttribute("org.eclipse.jetty.server.webapp.ContainerIncludeJarPattern", ".*/[^/]*\\.jar$");
		ClassList classlist = ClassList.setServerDefault(server);
		classlist.addBefore("org.eclipse.jetty.webapp.JettyWebXmlConfiguration",
                "org.eclipse.jetty.annotations.AnnotationConfiguration");	
	
		//Mapping
		//link the servletHandler to the URL and front end page/action
		context.addServlet("servlets.ServletHome", "/search");
		context.addServlet("servlets.ServletApi", "/api");
		
		//Setting the handler and starting the server
		server.setHandler(context);
		server.start();
		server.join();


	}

}
