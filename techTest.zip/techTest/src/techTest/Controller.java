package techTest;

import java.util.*;

import models.Driver;


public class Controller {

	static Scanner in = new Scanner(System.in);

	public static void main(String[] args) throws Exception {
		
		double puLat, puLong, doLat, doLong; 
		String pickup, dropoff;
		ArrayList<Driver> allTaxis = new ArrayList<>();
		HandlerApi api = new HandlerApi();
		
		System.out.println("----------------\n"
				+ "TAXI SEARCH ENGINE \n"
				+ "-------------------\n"
				+ "Enter pickup coordinates:\n"
				+ "Latitude: ");
		puLat = in.nextDouble();
		
		System.out.println("Longitude: ");
		puLong = in.nextDouble();
		
		System.out.println("Enter dropoff coordinates:\n"
				+ "Latitude: ");
		doLat = in.nextDouble();
		
		System.out.println("Longitude: ");
		doLong = in.nextDouble();
		
		
		pickup = puLat + "," + puLong;
		dropoff = doLat + "," + doLong;
		
		allTaxis = api.connection(pickup, dropoff);
		
		System.out.println("Taxis available: \n"
				+ allTaxis);
		
		in.close();
				
	}

}
