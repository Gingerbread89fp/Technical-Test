package servlets;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import com.google.gson.Gson;

import models.Driver;
import techTest.HandlerApi;

public class ServletApi extends HttpServlet {

	protected final static long serialVersionUID = 1L;
	
	HandlerApi api = new HandlerApi();
	Gson newGson = new Gson();
	ArrayList<Driver> taxiList = null;
	PrintWriter printer;
	
	//GET ALL TAXI DETAILS
	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//get all the values
		String pickup = request.getParameter("puLat")+","+request.getParameter("puLong");
		System.out.println("Pickup Api "+pickup);
		
		String dropoff = request.getParameter("doLat")+","+request.getParameter("doLong");
		System.out.println("Dropoff Api "+dropoff);
		
		//use a try/catch in case of errors
		try{ 
			taxiList = api.connection(pickup, dropoff);	
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		response.setContentType("application/JSON");
		printer = response.getWriter();
		String newJson = newGson.toJson(taxiList);
		
		printer.write(newJson);
		printer.close();
	}

}
