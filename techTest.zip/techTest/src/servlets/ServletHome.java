package servlets;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import models.Driver;
import techTest.HandlerApi;

public class ServletHome extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	HandlerApi api = new HandlerApi();
	ArrayList<Driver> allTaxis;
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{ 
			
		//get all the values
		String pickup = request.getParameter("puLat")+","+request.getParameter("puLong");
		System.out.println("Pickup Servlet "+pickup);
		
		String dropoff = request.getParameter("doLat")+","+request.getParameter("doLong");
		System.out.println("Dropoff Servlet "+dropoff);
		
		//use a try/catch in case of errors
		try{ 
			allTaxis = api.connection(pickup, dropoff);	
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		//forward the request object to the .jsp file*/
		RequestDispatcher disp = request.getRequestDispatcher("index.jsp");
		request.setAttribute("allTaxis", allTaxis);
		disp.forward(request, response);	
		
	}
	
}
